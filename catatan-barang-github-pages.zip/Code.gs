const HASIL_AKHIR = "HASIL AKHIR";

function doGet(e) {
  try {
    const action = e.parameter.action || "ping";
    if (action === "ping") return json({success:true,message:"API aktif"});
    if (action === "sheets") return json({success:true,sheets:daftarSheet()});
    if (action === "data") return json({success:true,data:ambilDataSheet(e.parameter.sheet)});
    if (action === "nama") return json({success:true,nama:ambilNama(e.parameter.sheet)});
    if (action === "hasil") return json({success:true,hasil:ambilHasil()});
    return json({success:false,message:"Action tidak dikenal"});
  } catch(err) {
    return json({success:false,message:String(err)});
  }
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || "{}");
    let result;

    if (data.action === "login") {
      result = autentikasi(data.kode);
    } else {
      if (!cekToken(data.token)) return json({success:false,message:"Tidak punya izin menulis"});
      switch (data.action) {
        case "buatSheet": result=buatSheet(data.nama); break;
        case "renameSheet": result=renameSheet(data.lama,data.baru); break;
        case "hapusSheet": result=hapusSheet(data.nama); break;
        case "simpanBarang": result=simpanBarang(data); break;
        case "editBarang": result=editBarang(data); break;
        case "hapusBarang": result=hapusBarang(data.sheet,data.id); break;
        case "tambahNama": result=tambahNama(data.sheet,data.nama); break;
        case "editNama": result=editNama(data.sheet,data.lama,data.baru); break;
        case "hapusNama": result=hapusNama(data.sheet,data.nama); break;
        default: result={success:false,message:"Action tidak dikenal"};
      }
    }
    return json(result);
  } catch(err) {
    return json({success:false,message:String(err)});
  }
}

function autentikasi(kode) {
  const secret=PropertiesService.getScriptProperties().getProperty("WRITE_KEY");
  if(!secret) return {success:false,message:"WRITE_KEY belum dibuat"};
  if(String(kode||"")!==String(secret)) return {success:false,message:"Kode akses salah"};
  const token=Utilities.getUuid();
  CacheService.getScriptCache().put("TOKEN_"+token,"OK",21600);
  return {success:true,token:token};
}
function cekToken(token) {
  if(!token) return false;
  return CacheService.getScriptCache().get("TOKEN_"+token)==="OK";
}

function daftarSheet() {
  return SpreadsheetApp.getActiveSpreadsheet().getSheets()
    .filter(s=>s.getName()!==HASIL_AKHIR).map(s=>s.getName());
}
function buatSheet(nama) {
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  nama=String(nama||"").trim();
  if(!nama)return {success:false,message:"Nama sheet kosong"};
  if(nama===HASIL_AKHIR)return {success:false,message:"Nama tersebut tidak boleh digunakan"};
  if(ss.getSheetByName(nama))return {success:false,message:"Sheet sudah ada"};
  const sheet=ss.insertSheet(nama);buatStrukturSheet(sheet);pindahkanHasilKePalingKanan();
  return {success:true,message:"Sheet berhasil dibuat",nama};
}
function buatStrukturSheet(sheet) {
  sheet.clear();
  sheet.getRange("A1:F1").setValues([["Tanggal","Nama Barang","Qty","Harga Satuan","Total","Punya"]]).setFontWeight("bold");
  sheet.getRange("D:E").setNumberFormat('"Rp" #,##0');
  sheet.setFrozenRows(1);
}
function renameSheet(lama,baru) {
  const ss=SpreadsheetApp.getActiveSpreadsheet(),sheet=ss.getSheetByName(lama);
  baru=String(baru||"").trim();
  if(!sheet)return {success:false,message:"Sheet tidak ditemukan"};
  if(!baru)return {success:false,message:"Nama baru kosong"};
  if(baru===HASIL_AKHIR)return {success:false,message:"Nama tersebut tidak boleh digunakan"};
  if(ss.getSheetByName(baru))return {success:false,message:"Nama sheet sudah digunakan"};
  sheet.setName(baru);updateHasilAkhir();
  return {success:true,message:"Nama sheet berhasil diubah"};
}
function hapusSheet(nama) {
  const ss=SpreadsheetApp.getActiveSpreadsheet(),sheet=ss.getSheetByName(nama);
  if(!sheet)return {success:false,message:"Sheet tidak ditemukan"};
  if(nama===HASIL_AKHIR)return {success:false,message:"HASIL AKHIR tidak boleh dihapus"};
  const sheets=ss.getSheets().filter(s=>s.getName()!==HASIL_AKHIR);
  if(sheets.length<=1)return {success:false,message:"Minimal harus ada satu sheet"};
  ss.deleteSheet(sheet);updateHasilAkhir();
  return {success:true,message:"Sheet berhasil dihapus"};
}

function simpanBarang(data) {
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(data.sheet);
  if(!sheet)return {success:false,message:"Sheet tidak ditemukan"};
  const qty=Number(data.qty)||0,harga=Number(data.harga)||0;
  if(!String(data.nama||"").trim())return {success:false,message:"Nama barang kosong"};
  if(qty<=0)return {success:false,message:"Qty harus lebih dari 0"};
  const total=qty*harga;
  sheet.appendRow([new Date(),String(data.nama).trim(),qty,harga,total,data.punya||""]);
  updateHasilAkhir();
  return {success:true,message:"Barang berhasil disimpan",total};
}

function editBarang(data) {
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(data.sheet);
  const row=Number(data.row);
  if(!sheet)return {success:false,message:"Sheet tidak ditemukan"};
  if(row<2||row>sheet.getLastRow())return {success:false,message:"Baris tidak valid"};
  const nama=String(data.nama||"").trim(),qty=Number(data.qty)||0,harga=Number(data.harga)||0;
  if(!nama)return {success:false,message:"Nama barang kosong"};
  if(qty<=0)return {success:false,message:"Qty harus lebih dari 0"};
  sheet.getRange(row,2,1,5).setValues([[nama,qty,harga,qty*harga,data.punya||""]]);
  updateHasilAkhir();
  return {success:true,message:"Barang berhasil diperbarui"};
}

function ambilDataSheet(nama) {
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nama);
  if(!sheet||sheet.getLastRow()<2)return [];
  return sheet.getRange(2,1,sheet.getLastRow()-1,6).getValues().map((r,i)=>({
    row:i+2,tanggal:formatTanggal(r[0]),nama:r[1],qty:r[2],harga:r[3],total:r[4],punya:r[5]
  })).reverse();
}
function hapusBarang(sheetName,row) {
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName),r=Number(row);
  if(!sheet)return {success:false,message:"Sheet tidak ditemukan"};
  if(r<2||r>sheet.getLastRow())return {success:false,message:"Baris tidak valid"};
  sheet.deleteRow(r);updateHasilAkhir();
  return {success:true,message:"Barang berhasil dihapus"};
}

function ambilNama(sheetName) {
  const props=PropertiesService.getDocumentProperties(),key="NAMA_"+sheetName,saved=props.getProperty(key);
  if(saved)return JSON.parse(saved);
  const list=["Aku","Dia"];props.setProperty(key,JSON.stringify(list));return list;
}
function tambahNama(sheetName,nama) {
  nama=String(nama||"").trim();if(!nama)return {success:false,message:"Nama kosong"};
  const list=ambilNama(sheetName);
  if(list.includes(nama))return {success:false,message:"Nama sudah ada"};
  list.push(nama);simpanNama(sheetName,list);return {success:true,nama:list};
}
function editNama(sheetName,lama,baru) {
  baru=String(baru||"").trim();if(!baru)return {success:false,message:"Nama baru kosong"};
  const list=ambilNama(sheetName),idx=list.indexOf(lama);
  if(idx===-1)return {success:false,message:"Nama tidak ditemukan"};
  if(list.includes(baru))return {success:false,message:"Nama baru sudah ada"};
  list[idx]=baru;simpanNama(sheetName,list);
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if(sheet&&sheet.getLastRow()>=2){
    const range=sheet.getRange(2,6,sheet.getLastRow()-1,1),values=range.getValues();
    values.forEach(r=>{if(r[0]===lama)r[0]=baru});range.setValues(values);
  }
  updateHasilAkhir();return {success:true,nama:list};
}
function hapusNama(sheetName,nama) {
  const list=ambilNama(sheetName);
  if(list.length<=1)return {success:false,message:"Minimal harus ada satu nama"};
  const idx=list.indexOf(nama);if(idx===-1)return {success:false,message:"Nama tidak ditemukan"};
  list.splice(idx,1);simpanNama(sheetName,list);return {success:true,nama:list};
}
function simpanNama(sheetName,list) {
  PropertiesService.getDocumentProperties().setProperty("NAMA_"+sheetName,JSON.stringify(list));
}

function updateHasilAkhir() {
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  let hasil=ss.getSheetByName(HASIL_AKHIR);
  if(!hasil)hasil=ss.insertSheet(HASIL_AKHIR);
  hasil.clear();
  hasil.getRange("A1:D1").setValues([["Sheet","Total Aku","Total Dia","Selisih"]]).setFontWeight("bold");
  const rows=[];
  ss.getSheets().filter(s=>s.getName()!==HASIL_AKHIR).forEach(sheet=>{
    let aku=0,dia=0;
    if(sheet.getLastRow()>=2){
      sheet.getRange(2,5,sheet.getLastRow()-1,2).getValues().forEach(r=>{
        const total=Number(r[0])||0,punya=String(r[1]||"");
        if(punya==="Aku")aku+=total;if(punya==="Dia")dia+=total;
      });
    }
    rows.push([sheet.getName(),aku,dia,Math.abs(aku-dia)]);
  });
  if(rows.length)hasil.getRange(2,1,rows.length,4).setValues(rows);
  hasil.getRange("B:D").setNumberFormat('"Rp" #,##0');hasil.setFrozenRows(1);
  pindahkanHasilKePalingKanan();
}
function ambilHasil() {
  updateHasilAkhir();
  const s=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HASIL_AKHIR);
  if(s.getLastRow()<2)return [];
  return s.getRange(2,1,s.getLastRow()-1,4).getValues().map(r=>({sheet:r[0],aku:r[1],dia:r[2],selisih:r[3]}));
}
function pindahkanHasilKePalingKanan() {
  const ss=SpreadsheetApp.getActiveSpreadsheet(),hasil=ss.getSheetByName(HASIL_AKHIR);
  if(!hasil)return;
  ss.setActiveSheet(hasil);ss.moveActiveSheet(ss.getSheets().length);
}
function formatTanggal(date) {
  if(!date)return "";
  return Utilities.formatDate(new Date(date),Session.getScriptTimeZone(),"dd/MM/yyyy HH:mm");
}
function json(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
